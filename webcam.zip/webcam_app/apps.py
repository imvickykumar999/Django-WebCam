from django.apps import AppConfig


class WebcamAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'webcam_app'
