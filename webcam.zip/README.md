# Install Daphne or Uvicorn if you haven't already
pip install daphne

# Run the server with Daphne
daphne -p 8000 webcam_project.asgi:application

# Run on IPV4 Network
daphne -b 0.0.0.0 -p 8000 webcam_project.asgi:application

